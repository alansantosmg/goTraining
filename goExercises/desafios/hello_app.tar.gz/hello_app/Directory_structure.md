# Minimal project strutcture 

This project represents the minimal struture for Golang projects. 

Structure: 
==========
gopath
     src
       github.com
            username
               project
                     cmd
                        binName1
                            binName.go (or main.go)
                        binName2
                            binName2.go
                     internal
                        package1
                            pkg1-file1.go
                            pkg1-file2.go
                            pkg1-file1_test.go
                            pkg1-file2_test.go
                        package2
                            pkg2-file1.go
                            pkg2-file1)test.goi


