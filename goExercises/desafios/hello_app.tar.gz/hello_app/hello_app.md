# Hello_app

## escription

Hello app is my first GO test driven app. It was designed to be a example about large projects
directory structure and TDD pratices using Golang.

## Features

 * Directory structure for large projects
 * Main program and functions are separated files
 * Main program and functions are separated packages
 * There's a test cases file for a package file
 * The test cases files are all commented
 * Use of consts, vars, arrays, ifs, switchs, strings, testing package,



Alan Santos - 2020-02-25
